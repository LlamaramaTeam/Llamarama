package io.github.llamarama.team.common.item;

import net.minecraft.item.Item;
import net.minecraft.item.MilkBucketItem;

public class LlamaMilkItem extends MilkBucketItem {

    public LlamaMilkItem(Item.Settings settings) {
        super(settings);
    }

}

