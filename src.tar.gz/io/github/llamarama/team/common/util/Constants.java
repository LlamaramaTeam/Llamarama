package io.github.llamarama.team.common.util;

import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;

public final class Constants {

    public static final Text CANNOT_RIDE_TEXT = new TranslatableText("message.llamarama.cannot_ride");

}
